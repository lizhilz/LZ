package com.aura;

public class BusinessProtocalImpl implements BusinessProtocal {
    @Override
    public void hello(String name) {
        System.out.println("hello： " + name);
    }

    @Override
    public String getName() {
        return "namenode";
    }
}
