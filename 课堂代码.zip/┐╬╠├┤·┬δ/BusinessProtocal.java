package com.aura;

public interface BusinessProtocal {


    void hello(String name);
    String getName();

    long versionID = 17739217394L;
}
