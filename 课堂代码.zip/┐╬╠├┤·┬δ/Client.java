package com.aura;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.ipc.RPC;

import java.io.IOException;
import java.net.InetSocketAddress;

/**
 * 客户端程序
 */
public class Client {

    public static void main(String[] args) {


        /**
         * 第一步：要获取到到远程服务器上的一个服务代理对象
         */
        try {
            BusinessProtocal proxy = RPC.getProxy(BusinessProtocal.class, BusinessProtocal.versionID,
                    new InetSocketAddress("localhost", 9977),
                    new Configuration());


            proxy.hello("huangbo");
            System.out.println(proxy.getName());


        } catch (IOException e) {
            e.printStackTrace();
        }


    }
}
