package com.aura;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.ipc.RPC;


/**
 * 服务端程序
 */
public class Server {
    public static void main(String[] args) {

        Configuration conf  = new Configuration();

        try {
            RPC.Server server = new RPC.Builder(conf)
                    .setProtocol(BusinessProtocal.class)
                    .setInstance(new BusinessProtocalImpl())
                    .setBindAddress("localhost")
                    .setPort(9977)
                    .build();

            server.start();
            System.out.println("服务器启动正常");

        }catch (Exception e){
            System.out.println("启动服务器异常");
        }
    }
}
